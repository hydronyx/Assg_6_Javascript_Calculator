function subtract (a,b) 
{
	if(Number(a) < Number(b) ) { alert( 'Second number should be smaller than the first. ' ); return "Cannot Procede"; }

	var decreasing = a.split(''); 
	var increasing = b.split(''); 

	while(decreasing.length > increasing.length) { increasing.unshift(0); }

	var i ;
	var remaining = []; 							// Number of remaining as a result of the process goes in this series

	for(i=0; i< decreasing.length; i++ ) 
	{
			if(decreasing[i] >= increasing[i]) 
			 { remaining[i]  = decreasing[i] - increasing[i];}

			if( decreasing[i] < increasing[i]) 
			 {  
				remaining[i-1]= remaining[i-1] - 1;           			 //  alert( 'remaining[i-1] = '+remaining[i-1]);
				decreasing[i]= Number(decreasing[i]) + 10;  			 // alert( 'decreasing[i]='+ decreasing[i] );
				remaining[i]  = decreasing[i] - increasing[i];   		 // alert( 'remaining[i]= '+ remaining[i]);
			 }
	}
	return  remaining.join('').replace(/^0+/,'') ;
}


function clr() {
var empty=" ";
var element = document.getElementById('Input');       // The empty variable is used to clear the display of calculator.
element.value = empty;
}


function appendToTextBox (val) {
var element = document.getElementById('Input');   
element.value += val;								 // print the elements on the text display box as soon as the number is clicked.
}


function calculate () 
{
try 
 { 
	var element = document.getElementById('Input');  // Input from the text box is taken in variable element.
	var s = element.value;							 // elements value assigned to variable s.
	var n = s.split(/[*+-\/]/);						 //  s is split using split function on the basis of the operators found.
	var sign = s.match(/[*+-\/]/);					 // sign carries the operator like +,-,*,/

	if(sign == '+' ) {element.value = Number(n[0]) + Number( n[1]); } 
  
	if(sign == '-' ) {element.value = subtract( n[0], n[1] ); } 
	// Alternative : if(sign == '-' ) {element.value = Number(n[0]) - Number( n[1]); } This gives negative output values as well.
	
	if(sign == '*' ) {element.value = Number(n[0]) * Number( n[1]); } 
	
	if(sign == '/' ) {element.value = Number(n[0]) / Number( n[1]); } 
 }
 
catch(e) 
 {
	  set('Error Occured.'); 
 } //try the above function,if fails give the exception.
}